# History, Queue Dashboard and Mastery Drill

🇪🇸 [Español](https://github.com/hugomarins/final-drill-and-history/blob/main/README_ES.md) | 🇧🇷 [Português Brasileiro](https://github.com/hugomarins/final-drill-and-history/blob/main/README_PT-BR.md)

This plugin extends RemNote's capabilities with a powerful suite of history and practice tools. It features a **Live Session Dashboard** for real-time study metrics (speed, retention, card age), a **Practiced Queues History** to track your sessions over time, a **Flashcard History** to quickly find and edit recently reviewed cards, a **Visited Rem History** to track your navigation in the knowledge base, and a **Mastery Drill** queue to target difficult material.

## Features

### 1. Visited Rem History
- **What it does:** Records a chronological history of the Rems you have navigated to in the Editor.
- **Why use it:** Quickly jump back to documents you were just working on without losing your place.
- **Interaction:** You can expand and edit the Rem directly in the right sidebar.
- **Search:** Includes a search bar to instantly filter your history. Supports multi-word queries (e.g., "Biology Exam") and deep text search across all recorded items.
![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/rem-history-editing.gif)

### 2. Flashcard History
- **What it does:** Records the chronological history of the Rems associated with the flashcards you have just seen in the Flashcard Queue.
- **Why use it:** If you want to check context or edit a flashcard you just reviewed, you can easily find it here without interrupting your session flow.
- **Interaction:** Clicking on a flashcard will open the rem in the Editor.
- **Search:** Effortlessly find a card you practiced moments or days ago. The search checks both the front (question) and back (answer/context) of your cards.
![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/flashcard-history.png)

![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/filter.gif)


### 3. Practiced Queues History
- **What it does:** Tracks your practice sessions and metrics. 
- **Live Dashboard:** Displays real-time metrics for your currently active queue session, including current speed, retention rate, and the age of the exact card you are reviewing.
- **Metrics Collected:** 
    - Total time spent studying.
    - **Retention Rate:** Track your performance (Remembered vs. Forgot) and percentage.
    - **Speed Analysis:** Cards per minute (CPM) and seconds per card, with visual speed indicators.
    - **Sessions Summary:** A dashboard aggregating your stats for Today, Yesterday, This Week, Last Week, and more.
    - Number of Flashcards reviewed and time spent on them.
    - Number of "Incremental Rems" (from Incremental Everything plugin) processed and time spent on them.
- **Why use it:** Gain insights into your study habits, track your velocity, and monitor your usage of incremental reading tools alongside standard flashcards.
- **Interaction:** Clicking on a session will open the document in the Editor, so that you can review the material again.
![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/queue-history.png)

![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/queue-history-live.png)

### 4. Mastery Drill
- **What it does:** Implements a "Mastery Drill" queue inspired by SuperMemo's "Final Drill", accessible using the command `Mastery Drill` in the Omnibar or from the Left Sidebar End widget. 
- **How it works:** 
    - Any flashcard you rate as **Forgot** or **Hard** is automatically added to the Mastery Drill queue.
      - **Forgot** usually already have a relearning step. If you do this relearning step successfully, the card will be cleared from the Mastery Drill queue; if not, doing it in the Mastery Drill will be the same as doing it away from it. The purpose of having these cards in the drill is to ensure you accomplish the relearning step (in case you usually make flashcards in document queues rather than in the global queue).
      - **Hard** is what brings the real difference. Drilling these cards is as if you were reviewing ahead of time; algorithms (especially FSRS) account for that, and the interval rendered will be practically the same as the one already assigned. The purpose of having them in the drill is to ensure you have raised retrievability close to 100% (the same purpose of the relearning step for forgotten items).
      - Unlike _SuperMemo_, these reviews will be recorded in your repetition history.
    - These cards stay in this separate queue until you rate them **Good** or **Easy** inside the Mastery Drill widget.
- **Why use it:** Use this to review only the items you struggled with recently, ensuring you master them. Working in the difficult-only mode sets your brain onto an emergency alertness level. You approach repetitions differently if recall failure is expected. At time, this is enough to wrap your mind around harder material and gradually master them. This mode is designed to ensure you have raised retrievability of the most difficult material close to 100% (in other words, that you have ingrained the content and know it). 
- **Do I have to use it?:** Have in mind that this is an optional stage of the learning process. Not using it will not bring negative consequences for your learning process, as in the next scheduled repetition, you'll be tested again, and failures will be treated accordingly by the algorithm. But using the drill will not cost much and will increase the chances of success in the subsequent repetitions.
- **Queue Management:**
    - **Old Items:** If items linger in the queue for too long (default 7 days), a warning will appear. You can clear these stale items with a single click to keep your drill session focused on fresh material. The threshold can be configured in the plugin settings.
    - **Clear Queue:** A "Clear Queue" button allows you to empty the Mastery Drill queue at any time if you want to start fresh or simply declutter.
- **Know limitations:** irresponsive to keyboard shortcuts, and no access to Edit / Preview buttons. As a workaound, a Editor UI is accessible by buttons (as it is still limited, there is an "Edit Later" to remove the card from the Mastery Drill queue and add the Edit Later built-in powerup, and a "Go to Rem" button to jump to the Rem in RemNote native Editor).

![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/final-drill.png)

![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/final-drill-editor.png)

## How to Use

1. **Open the Right Sidebar**: The plugin installs three widgets in the right sidebar.
2. **Rem History Tab**: 
   - Navigate through your knowledge base as usual.
   - Click items in the list to navigate back to them.
3. **Flashcard History Tab**: 
   - Start a flashcard queue. As you rate cards, they will appear in this list.
   - Click on a rem to open it in the main editor.
4. **Practiced Queue History Tab**: 
   - Want to go back to queues you started but was not able to finish? Click on the queue name to navigate back to it.
   - Monitor here the stats of your practiced queues.
5. **Mastery Drill command**: 
   - If you rate a card "Forgot" or "Hard" during your regular queue (or anywhere else), a red badge will appear on this tab indicating cards are pending.
   - Use the command `Mastery Drill` in the Omnibar to practice these specific cards (or press the button of the widget that appears from time to time in the Left Sidebar End).
   - The queue will automatically clear as you master the cards (rate them Good/Easy).
   ![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/final-drill-notification.png)

   ![](https://raw.githubusercontent.com/hugomarins/final-drill-and-history/main/images/final-drill-command.png)

## Changelog

### v. 0.0.31 March 09th, 2026

- **Bug Fix:** Fixed issue caused by audio or other complex media elements inside flashcards leading to the "Invalid input" error, halting the script execution.

### v. 0.0.28 February 09th, 2026

- **Bug Fix:** Fixed the "Previous Card" box showing stale data when the current card is "New" (no history).
- **Improvement:** "Card Age" and intervals now display hours and minutes for durations under 24 hours (e.g., "4h", "30min") instead of "New".
- **Renaming:** "Final Drill" has been renamed to **Mastery Drill** to better reflect its purpose and avoid confusion with other tools.

### v. 0.0.27 February 08th, 2026

- **Bug Fix:** Fixed the **Clear Queue** and **Clear Old** buttons not showing the confirmation dialogs.

### v. 0.0.25 February 2nd, 2026

- **Improvement:** Enhanced the Live Session card display to show the **interval** (time until next review) for both the current and previous card. For the previous card, also displays the **total coverage** (time span from card creation to next due date), providing insight into your learning progress.
- **New Metric:** Added a **Cost** metric (minutes per year) to the Live Session dashboard.
    - **Previous Card Box:** Shows the cost as `Total Time (min) / Coverage (years)`.
    - **Current Card Box:** Shows the cost as `Total Time (min) / Card Age (years)`.
- **UI Improvement:** The metrics in the Current Card box now wrap naturally to fit available space.

### v. 0.0.23 January 29th, 2026

- **Improvement:** Increased the flashcard history search text limit from 200 to 1000 characters per side (front/back), significantly improving search coverage for longer flashcards.

### v. 0.0.22 January 28th, 2026

- **Bug Fix:** Fixed an issue where skipped cards (`TOO_EARLY`) were incorrectly being added to the Final Drill queue. Now only cards explicitly rated **Again** or **Hard** are added.
- **New Feature:** Added an **Edit Later** button to the Final Drill widget (between "Go to Rem" and "Edit Previous"). Clicking it marks the current card's Rem with the "Edit Later" powerup and removes the card from the drill queue, allowing you to defer editing without losing track of it.

### v. 0.0.21 January 21st, 2026

- **Bug Fix:** Reduced the maximum number of flashcards stored in history to 999 to prevent performance issues. 
- **Feature:** Added a debug command to clear flashcard history in case the user faces syncing issues ("Debug: Clear Flashcard History").

### v. 0.0.20 January 21st, 2026

- **Bug Fix:** Implemented lazy session initialization in `index.tsx` to handle missing QueueEnter events on iOS.

### v. 0.0.19 January 20th, 2026

- **Bug Fix:** Fixed an issue where the Final Drill widget was incorrectly showing "0 cards" or "Finished" even when there were cards remaining in the queue.

### v. 0.0.18 January 18th, 2026

- **Bug Fix:** The "Previous Card" stats in the live dashboard now reflect the final state of the card after it was reviewed, including the time spent and the repetition count increment.

### v. 0.0.17 January 17th, 2026

- **Bug Fix:** Solved an issue where the Final Drill was recording a separate session for each card reviewed, instead of a single continuous session.

### v. 0.0.16 January 10th, 2026

- **Bug Fix:** Solved an issue where practice sessions were not being recorded when navigating away from the queue (e.g., by clicking a link or opening a Rem) instead of using the close button.

### v. 0.0.12 January 09th, 2026

- **Practiced Queues Upgrade:**
    - **Live Session Dashboard:** A new real-time view at the top of the widget showing your current session's progress.
    - **History Summary:** A comprehensive table showing aggregated stats (Time, Cards, Speed, Retention) for Today, Yesterday, Last Week, etc.
    - **New Metrics:**
        - **Retention Rate:** See exactly how many cards you remembered vs. forgot.
        - **Cards Per Minute (CPM):** Color-coded speed metric to track your velocity.
        - **Card Age:** (Live View only) See the age (time since creation) of the card you are currently reviewing.

### v. 0.0.8 January 07th, 2026

- **Final Drill** now is shown in a popup. 
- **Know limitations:** irresponsive to keyboard shortcuts, and no access to Edit / Preview buttons. As a workaound, a Editor UI is accessible by buttons (as it is still limited, there is a "Go to Rem" button to jump to the Rem in RemNote native Editor). 

### v. 0.0.7 January 07th, 2026

- **Search Filter:** Added a powerful search bar to "Visited Rem History" and "Flashcard History".
    - Filter history items instantly by text.
    - Supports multi-word searches (prioritizes exact matches).
    - **Flashcard Context:** Search includes the **Back Text** (content) of your flashcards, making it easier to find items based on their answer or context.
    - **Backfill:** Existing history items are automatically updated in the background to include searchable text.

### v. 0.1.6 January 07th, 2026

- Solved a bug where the Final Drill could clash with the main queue.

### v. 0.1.4 January 06th, 2026

- **Practiced Queues History:**
    - Implemented metrics tracking, distinguishing between Regular Flashcards and Incremental Rems.
    - Implemented dashboard to view detailed breakdowns of Cards vs IncRems counts and times for each session.

### v. 0.1.3 January 06th, 2026

- **Final Drill Improvements:** 
    - Added a "Clear Queue" button to easy empty the drill queue.
    - Added an "Old Items" warning to help identify and clear stale items (added > 7 days ago).
    - Added a new setting to configure the "Old Items Threshold" (default: 7 days).

### v. 0.0.2 January 05th, 2026

- Plugin features (Rem History, Flashcard History and Final Drill) are now Knowledge Base aware (you can use multiple KBs, and the widgets will show the data of the current selected KB only).

### v. 0.0.1 January 04th, 2026

- Initial release.